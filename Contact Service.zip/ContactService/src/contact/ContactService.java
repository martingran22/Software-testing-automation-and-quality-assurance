package contact;

import java.util.ArrayList;


public class ContactService {
	
	private ArrayList <Contact> contacts; 
	
	public ContactService (){
		contacts = new ArrayList <> (); //creating array to hold objects
	}
	
	public boolean addContact(Contact contactList) { //objects of Contact 
		
		boolean contactadded = true; //boolean set as true
		for (Contact listedContacts:contacts) { //go through the array
			if (listedContacts.equals(contactList)) {
				contactadded = false; // if contact in list, set boolean to false
			}
		}
		
		if (contactadded) { //if true then return true as a contact was added
			contacts.add(contactList);
			return true;
		}else { //else return false
			return false;
		}
	}
	
	public boolean deleteContact(String contactId) { //delete contacts
		for (Contact listedContact:contacts) {
			if (listedContact.getContactId().equals(contactId)){ // if contact exits with contact ID delete
				contacts.remove(listedContact);
				return true;
			}
		}
		return false;
	}
	
	public boolean updateContact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
	//run through loop again
	boolean contactUpdated = false;
	for (Contact contactList:contacts) { //run through each contact
		if (contactList.getContactId().equals(contactID)) { //if contactID matches
			if(firstName == null || firstName.length() > 10 || // if new updates do not match requirements, set as false
					lastName == null || lastName.length() > 10 ||
					phoneNumber == null || phoneNumber.length() != 10 ||
					address == null || address.length() > 30){
				contactUpdated = false;
				break;
			}else {
				contactList.setFirstName(firstName); // if they match requirements, update contact
				contactList.setLastName(lastName);
				contactList.setPhone(phoneNumber);
				contactList.setAddress(address);
				contactUpdated = true;
			}
		}
	}

	return contactUpdated;
	}
	
	

}
