package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import contact.Contact;
import contact.ContactService;

class ContactServiceTest {

	@Test
	public void testAdd()
	{
	ContactService contact = new ContactService();
	Contact test = new Contact("1245637", "Jerry", "Mann", "6265987485", "3131 Laney Rd.");
	assertEquals(true, contact.addContact(test));
	assertEquals(false, contact.addContact(test));
	}

	@Test
	public void testDelete()
	{
	ContactService contact = new ContactService();

	Contact test1 = new Contact("1245637", "Jerry", "Mann", "6265987485", "3131 Laney Rd.");
	Contact test2 = new Contact("5489785", "Wally", "Smith", "9294856981", "Huntington Drive");

	contact.addContact(test1);
	contact.addContact(test2);

	assertEquals(true, contact.deleteContact("1245637")); //testing deleting contact
	assertEquals(true, contact.deleteContact("5489785")); //testing deleting contact
	assertEquals(false, contact.deleteContact("1245637")); //testing contact thats has already been deleted
	assertEquals(false, contact.deleteContact("9752319")); //testing deleting contact that does not exist
	}

	@Test
	public void testUpdate(){
	ContactService contact = new ContactService();

	Contact test1 = new Contact("1245637", "Jerry", "Mann", "6265987485", "3131 Laney Rd.");
	Contact test2 = new Contact("5489785", "Wally", "Smith", "9294856981", "Huntington Drive");
	Contact test3 = new Contact("1234568", "Manny", "Wong", "3237845897", "Washington Lane");

	contact.addContact(test1);
	contact.addContact(test2);
	contact.addContact(test3);

	assertEquals(true, contact.updateContact("1245637", "Walter", "Peter", "1457845623", "Ocean Drive"));
	assertEquals(true, contact.updateContact("5489785", "Mary", "Tom", "4444444444", "Sample 24 Drive"));
	assertEquals(true, contact.updateContact("1234568", "Mary", "Doe", "3265478169", "123 Happy Lane"));
	
	assertEquals(false, contact.updateContact("1245639", "Jane", "Oswald", "9524859645", "1st Street")); //testing wrong ID
	assertEquals(false, contact.updateContact("1245637", "Walter Bryce the 3rd", "Oswald", "9524859645", "1st Street")); //first name too long
	assertEquals(false, contact.updateContact("1245637", "Jane", "Gonzalez Rodriguez", "9524859645", "1st Street")); //last name too long
	assertEquals(false, contact.updateContact("5489785", "Mary", "Fernandez", "54897895484", "2nd Street")); //phone number too long
	assertEquals(false, contact.updateContact("5489785", "Cesar", "Rodriguez", "14589", "Sample 24 Drive")); //phone number too short
	assertEquals(false, contact.updateContact("1234568", "Cesar", "Rodriguez", "9524859645", "3131 Washington Boulevard, Los Angeles, CA")); //address too long
	assertEquals(false, contact.updateContact("1234568", "Jane", "Doe", "4444444444", "3131 Washington Boulevard, Los Angeles, CA"));
	
	//testing null variables
	assertEquals(false, contact.updateContact(null, "Cesar", "Lopez", "4548945623", "Broadway Avenue"));
	assertEquals(false, contact.updateContact("1245637", null, "Lopez", "4548945623", "Broadway Avenue"));
	assertEquals(false, contact.updateContact("1245637", "Walter", null, "4548945627", "Broadway Avenue"));
	assertEquals(false, contact.updateContact("1234568", "Walter", "Lopez", null, "Broadway Avenue"));
	assertEquals(false, contact.updateContact("1234568", "Walter", "Lopez", "4548945627", null));
	}

	}
