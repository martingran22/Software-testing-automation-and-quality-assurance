package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import contact.Contact;


class ContactTest {

	@Test
	void testContact() {
		Contact contact = new Contact("1245637", "Jerry", "Mann", "6265987485", "3131 Laney Rd.");
		assertTrue(contact.getContactId().equals("1245637"));
		assertTrue(contact.getFirstName().equals("Jerry"));
		assertTrue(contact.getLastName().equals("Mann"));
		assertTrue(contact.getPhone().equals("6265987485"));
		assertTrue(contact.getAddress().equals("3131 Laney Rd."));
	}
	
	//tests below are testing requirements
	@Test
	void testContactIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("12345678910", "Jerry", "Mann", 
				"6265987485", "3131 Laney Rd.");
		});
	}
	
	@Test
	void testContactIdIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact(null, "Jerry", "Mann", 
				"6265987485", "3131 Laney Rd.");
		});
	}
	
	@Test
	void testFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1245637", "Jerry Manuel", "Mann", 
				"6265987485", "3131 Laney Rd.");
		});
	}
	
	@Test
	void testFirstNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("12345678910", null, "Mann", 
				"6265987485", "3131 Laney Rd.");
		});
	}
	
	@Test
	void testLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1245637", "Jerry", "Mann Rodriguez", 
				"6265987485", "3131 Laney Rd.");
		});
	}
	
	@Test
	void testLastNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("12345678910", "Jerry", null, 
				"6265987485", "3131 Laney Rd.");
		});
	}
	
	@Test
	void testPhoneTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1245637", "Jerry", "Mann", 
				"62659874855", "3131 Laney Rd.");
		});
	}
	
	@Test
	void testPhoneIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("12345678910", "Jerry", "Mann", 
				null, "3131 Laney Rd.");
		});
	}
	
	@Test
	void testPhoneTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("12345678910", "Jerry", "Mann", 
				"626598748", "3131 Laney Rd.");
		});
	}
	
	@Test
	void testAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1245637", "Jerry", "Mann", "6265987485", 
					"3131 Washington Boulevard, Los Angeles, California");
		});
	}
	
	@Test
	void testAddressIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("12345678910", "Jerry", "Mann", "62659874855", null);
		});
	}
}

